package com.example.tomatoselect;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.graphics.Path;
import android.graphics.Point;
import android.hardware.HardwareBuffer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.WindowManager;
import android.widget.Toast;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

public class CaptureAccessibilityService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private String readerPackage;
    private String lastNormalized = "";
    private int samePageCount = 0;
    private int pageCount = 0;
    private boolean started = false;
    private String prefsName() { return "capture_settings"; }

    @Override protected void onServiceConnected() { super.onServiceConnected(); }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || !getSharedPreferences(prefsName(), MODE_PRIVATE).getBoolean("active", false)) return;
        if (started || busy.get()) return;
        CharSequence packageName = event.getPackageName();
        if (packageName == null || getPackageName().contentEquals(packageName)) return;
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.getEventType() != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && event.getEventType() != AccessibilityEvent.TYPE_VIEW_SCROLLED) return;
        String candidate = packageName.toString();
        handler.removeCallbacks(waitingCapture);
        waitingPackage = candidate;
        handler.postDelayed(waitingCapture, 700);
    }

    private String waitingPackage;
    private final Runnable waitingCapture = () -> captureScreen(true, waitingPackage);

    private void captureScreen(boolean lookingForReader, String packageName) {
        if (!getSharedPreferences(prefsName(), MODE_PRIVATE).getBoolean("active", false) || !busy.compareAndSet(false, true)) return;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) { fail("Cần Android 11 trở lên để chụp màn hình tự động"); return; }
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult result) {
                Bitmap bitmap = null;
                HardwareBuffer buffer = result.getHardwareBuffer();
                try {
                    ColorSpace cs = result.getColorSpace();
                    Bitmap hw = Bitmap.wrapHardwareBuffer(buffer, cs);
                    if (hw == null) { busy.set(false); return; }
                    bitmap = hw.copy(Bitmap.Config.ARGB_8888, false);
                } catch (Exception e) { busy.set(false); return; }
                finally { buffer.close(); }
                Bitmap frame = bitmap;
                InputImage image = InputImage.fromBitmap(frame, 0);
                TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build()).process(image)
                    .addOnSuccessListener(text -> {
                        String value = text.getText() == null ? "" : text.getText().trim();
                        frame.recycle();
                        if (!getSharedPreferences(prefsName(), MODE_PRIVATE).getBoolean("active", false)) { busy.set(false); return; }
                        if (lookingForReader) {
                            if (countChinese(value) < 25) { busy.set(false); return; }
                            started = true; readerPackage = packageName;
                        }
                        String normalized = value.replaceAll("[\\s\\p{Punct}，。！？、；：‘’“”【】（）《》…·]+", "");
                        if (normalized.length() < 10) { busy.set(false); scheduleNext(); return; }
                        if (normalized.equals(lastNormalized)) samePageCount++; else { samePageCount = 0; lastNormalized = normalized; appendText(value); pageCount++; }
                        if (samePageCount >= 2 || pageCount >= 2000) { stopSession(samePageCount >= 2 ? "检测到重复页面，已停止" : "已到 2000 页上限"); return; }
                        busy.set(false);
                        turnPage();
                    })
                    .addOnFailureListener(e -> { frame.recycle(); busy.set(false); scheduleNext(); });
            }
            @Override public void onFailure(int errorCode) {
                busy.set(false);
                if (lookingForReader && getSharedPreferences(prefsName(), MODE_PRIVATE).getBoolean("active", false)) handler.postDelayed(() -> captureScreen(true, packageName), 1800);
                else scheduleNext();
            }
        });
    }

    private int countChinese(String s) {
        int n = 0; for (int i = 0; i < s.length(); i++) { Character.UnicodeBlock b = Character.UnicodeBlock.of(s.charAt(i)); if (b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS || b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A || b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B) n++; } return n;
    }

    private void appendText(String text) {
        try {
            String raw = getSharedPreferences(prefsName(), MODE_PRIVATE).getString("output_uri", null);
            if (raw == null) { fail("Chưa chọn file TXT"); return; }
            Uri uri = Uri.parse(raw);
            OutputStream out = getContentResolver().openOutputStream(uri, "wa");
            if (out == null) { fail("Không mở được file đích"); return; }
            OutputStreamWriter writer = new OutputStreamWriter(out, StandardCharsets.UTF_8);
            writer.write(text); writer.write("\n\n"); writer.flush(); writer.close();
        } catch (Exception e) { fail("Không ghi được file TXT"); }
    }

    private void turnPage() {
        if (!getSharedPreferences(prefsName(), MODE_PRIVATE).getBoolean("active", false)) { busy.set(false); return; }
        Point size = new Point(); ((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealSize(size);
        float x = size.x * 0.83f, y = size.y * 0.50f;
        Path path = new Path(); path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 70);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gesture) { handler.postDelayed(() -> captureScreen(false, readerPackage), 1200); }
            @Override public void onCancelled(GestureDescription gesture) { handler.postDelayed(() -> captureScreen(false, readerPackage), 1500); }
        }, null);
    }

    private void scheduleNext() { if (started && getSharedPreferences(prefsName(), MODE_PRIVATE).getBoolean("active", false)) handler.postDelayed(() -> captureScreen(false, readerPackage), 1600); }

    private void stopSession(String message) {
        getSharedPreferences(prefsName(), MODE_PRIVATE).edit().putBoolean("active", false).apply(); started = false; busy.set(false); Toast.makeText(this, message + " — đã lưu " + pageCount + " trang", Toast.LENGTH_LONG).show();
    }

    private void fail(String message) { getSharedPreferences(prefsName(), MODE_PRIVATE).edit().putBoolean("active", false).apply(); started = false; busy.set(false); Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    @Override public void onInterrupt() { busy.set(false); }
}
