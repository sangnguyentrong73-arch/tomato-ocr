package com.example.tomatoselect;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int CREATE_TEXT = 17;
    static final String PREFS = "capture_settings";
    static final String OUTPUT_URI = "output_uri";
    static final String ACTIVE = "active";
    private TextView selectedFile;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL); page.setPadding(24, 28, 24, 20);
        page.setBackgroundColor(Color.rgb(247, 248, 243));
        TextView title = new TextView(this); title.setText("OCR trang → file TXT"); title.setTextSize(23); title.setTextColor(Color.BLACK); page.addView(title);
        TextView info = new TextView(this); info.setText("Chọn file lưu, bật Trợ năng rồi bấm Bắt đầu. Mở trình đọc của bạn; app chờ trang có chữ Trung, chụp trong bộ nhớ, nối chữ vào file và tự lật trang. Không lưu ảnh chụp."); info.setTextSize(15); info.setTextColor(Color.DKGRAY); info.setPadding(0, 12, 0, 14); page.addView(info);
        Button choose = new Button(this); choose.setText("Chọn / tạo file TXT"); choose.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TITLE, "truyen-ocr.txt"); startActivityForResult(i, CREATE_TEXT); }); page.addView(choose);
        selectedFile = new TextView(this); selectedFile.setTextSize(14); selectedFile.setTextColor(Color.DKGRAY); selectedFile.setPadding(4, 2, 4, 8); updateFileLabel(prefs); page.addView(selectedFile);
        Button access = new Button(this); access.setText("Bật quyền Trợ năng"); access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); page.addView(access);
        Button start = new Button(this); start.setText("Bắt đầu chờ trang"); start.setOnClickListener(v -> {
            if (prefs.getString(OUTPUT_URI, null) == null) { Toast.makeText(this, "Chọn file TXT trước", Toast.LENGTH_LONG).show(); return; }
            if (!isServiceEnabled()) { Toast.makeText(this, "Bật dịch vụ OCR trang trong cài đặt Trợ năng trước", Toast.LENGTH_LONG).show(); startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return; }
            prefs.edit().putBoolean(ACTIVE, true).apply(); Toast.makeText(this, "Đang chờ trang truyện; mở app đọc của bạn", Toast.LENGTH_LONG).show(); moveTaskToBack(true);
        }); page.addView(start);
        Button stop = new Button(this); stop.setText("Dừng"); stop.setOnClickListener(v -> { prefs.edit().putBoolean(ACTIVE, false).apply(); Toast.makeText(this, "Đã dừng", Toast.LENGTH_SHORT).show(); }); page.addView(stop);
        TextView note = new TextView(this); note.setText("Khi chạy: OCR nhận chữ Trung trên màn hình, lưu nội dung vào file đã chọn, rồi chạm giữa bên phải để qua trang. Mở lại app và bấm Dừng để kết thúc."); note.setTextSize(14); note.setTextColor(Color.GRAY); note.setPadding(4, 12, 4, 0); page.addView(note);
        setContentView(page);
    }

    private boolean isServiceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.toLowerCase().contains(getPackageName().toLowerCase());
    }

    private void updateFileLabel(SharedPreferences p) {
        String raw = p.getString(OUTPUT_URI, null);
        selectedFile.setText(raw == null ? "Chưa chọn file." : "File đích đã được chọn.");
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != CREATE_TEXT || result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(OUTPUT_URI, uri.toString()).apply();
        updateFileLabel(getSharedPreferences(PREFS, MODE_PRIVATE));
    }
}
