package com.example.tomatoselect;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 42;
    private TextView result;
    private Button copy;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL); page.setPadding(22, 22, 22, 12);
        page.setBackgroundColor(Color.rgb(247, 248, 243));
        TextView title = new TextView(this); title.setText("Trích chữ từ ảnh"); title.setTextSize(23); title.setTextColor(Color.BLACK); page.addView(title);
        TextView info = new TextView(this); info.setText("Chọn ảnh chụp màn hình. App nhận dạng chữ Trung giản thể để bạn xem lại và sao chép."); info.setTextSize(15); info.setTextColor(Color.DKGRAY); info.setPadding(0, 10, 0, 12); page.addView(info);
        Button choose = new Button(this); choose.setText("Chọn ảnh chụp"); choose.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*"); startActivityForResult(Intent.createChooser(i, "Chọn ảnh"), PICK_IMAGE); }); page.addView(choose);
        copy = new Button(this); copy.setText("Sao chép văn bản"); copy.setEnabled(false); copy.setOnClickListener(v -> { ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("OCR", result.getText())); Toast.makeText(this, "Đã sao chép", Toast.LENGTH_SHORT).show(); }); page.addView(copy);
        ScrollView scroll = new ScrollView(this); result = new TextView(this); result.setText("Văn bản nhận dạng sẽ hiện ở đây."); result.setTextSize(18); result.setTextColor(Color.BLACK); result.setTextIsSelectable(true); result.setPadding(4, 14, 4, 24); scroll.addView(result, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        page.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1)); setContentView(page);
    }

    @Override protected void onActivityResult(int request, int code, Intent data) {
        super.onActivityResult(request, code, data);
        if (request != PICK_IMAGE || code != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData(); result.setText("Đang nhận dạng..."); copy.setEnabled(false);
        try {
            InputImage image = InputImage.fromFilePath(this, uri);
            TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build()).process(image)
              .addOnSuccessListener(text -> { String s = text.getText(); result.setText(s.isEmpty() ? "Không thấy chữ. Hãy chọn ảnh rõ hơn." : s); copy.setEnabled(!s.isEmpty()); })
              .addOnFailureListener(e -> result.setText("Lỗi OCR: " + e.getLocalizedMessage()));
        } catch (Exception e) { result.setText("Không mở được ảnh: " + e.getLocalizedMessage()); }
    }
}
