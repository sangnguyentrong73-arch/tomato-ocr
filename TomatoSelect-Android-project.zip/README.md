# OCR trang (Android)

App chờ màn hình đọc có nội dung tiếng Trung, chụp màn hình vào bộ nhớ, OCR giản thể, nối chữ vào file TXT do người dùng chọn, rồi chạm giữa bên phải để qua trang. Ảnh chụp không được ghi ra đĩa; bitmap trong bộ nhớ được giải phóng sau OCR. Dừng phiên bằng cách mở app và nhấn **Dừng**.

## Cài đặt trên điện thoại

1. Chọn hoặc tạo file TXT.
2. Bật dịch vụ **OCR trang - điều khiển trang** trong Cài đặt > Trợ năng.
3. Bấm **Bắt đầu chờ trang**, rồi mở app đọc của bạn. Khi nhận ra trang có đủ chữ Trung, app bắt đầu OCR và tự chuyển trang.
4. Mở lại OCR trang và bấm **Dừng** để kết thúc.

App yêu cầu Android 11 trở lên để AccessibilityService chụp màn hình. Để đổi vị trí bấm qua trang, sửa hệ số `0.83f` và `0.50f` trong `CaptureAccessibilityService.java`.

## Build APK bằng GitHub Actions

Workflow `.github/workflows/build-apk.yml` build APK debug mỗi lần cập nhật mã nguồn. Tải `TomatoSelect-debug-apk` ở phần Artifacts của lần chạy Actions thành công, giải nén và cài `app-debug.apk`.
