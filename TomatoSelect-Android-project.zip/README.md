# Trích chữ từ ảnh truyện (Android)

App nhỏ nhận dạng chữ Trung giản thể từ ảnh chụp màn hình bạn chọn, hiển thị kết quả để rà soát và cho phép sao chép. App không tự điều khiển Cà Chua, không cuộn trang và không tải hàng loạt nội dung.

## Build APK bằng GitHub Actions

1. Tạo một repository GitHub mới và tải các file trong thư mục này lên đó.
2. Mở tab **Actions**, chọn workflow **Build Android APK**, rồi bấm **Run workflow** (hoặc đẩy một commit lên repo).
3. Khi run hiện **Success**, mở run đó, kéo xuống **Artifacts**, tải `TomatoSelect-debug-apk.zip` và giải nén để lấy `app-debug.apk`.
4. Chuyển APK sang điện thoại, mở file và cho phép cài ứng dụng từ nguồn này nếu Android hỏi.

APK debug dùng để cài thử, không phải bản phát hành Play Store. Workflow nằm ở `.github/workflows/build-apk.yml`.
